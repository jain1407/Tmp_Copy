The documentation can be created by running ``make`` (``make html``, ``make 
pdf``, etc.).

Creating the documentation requires `Sphinx 
<http://sphinx-doc.org/index.html>`_.